function Get-Stuff {
    "Hello"
}

Export-ModuleMember -Function Get-Stuff